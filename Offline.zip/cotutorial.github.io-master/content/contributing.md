---
title: Contribusi 📨️
noTimeEstimate: true
url: /contribusi/
aliases:
  - /contribution/
page: true
---

## Kenapa sih Kontribusi di CoTutorial?
loremsakl jkg