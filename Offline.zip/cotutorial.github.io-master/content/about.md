---
title: About 😊
url: /about/
noTimeEstimate: true
page: true
---

```
Welcome to CoTutorial
```
<br>

### Apa itu CoTutorial
**CoTutorial** adalah sebuah website edukasi yang menyediakan tutorial secara gratis. CoTutorial ini bersifat open source, memungkinkan semua orang bisa [berkontribusi](/contribusi) di sini. 

### Kenapa Saya Membuat CoTutorial?
CoTutorial ini sebagai tempat saya untuk menulis catatan tentang ilmu yang telah saya pelajari saat ini. Tidak hanya itu CoTutorial ini saya gunakan untuk membagikan ilmu yang saya telah pelajari. Dengan saya membagikan ilmu saya, bisa menambah kepahaman ilmu atau materi yang telah saya pelajari, karena dengan membagikannya saya harus paham suatu materi itu dengan benar. 

Manamungkin kita membagikan suatu Ilmu secara tidak benar, maka sebelum kita membagikan ilmu itu kita harus paham suatu Ilmu itu.

Walaupun content disini kurang sempurna setidaknya saya masih bisa membagikan ilmu saya ke semua orang, siapa tahu dengan tulisan saya bisa bermanfaat.