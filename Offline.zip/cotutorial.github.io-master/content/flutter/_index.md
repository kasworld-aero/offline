---
title: Flutter
url: /flutter/
noTimeEstimate: true
page: true
---

Flutter  adalah SDK (Software Development Kit) yang dibuat oleh tim Google untuk membuat berbagai macam aplikasi: Mobile, Web, Desktop. Flutter dibuat dengan bahasa Dart. Flutter dibuat seperti layaknya performa native seperti Android/IOS. Flutter dapat digunakan oleh semua orang/developer di seluruh dunia karena Flutter tidak close source berarti Flutter bersifat open source dan gratis.  Flutter adalah aplikasi native, dia dengan mudah memanggil kode dari native seperti  java,kotlin, swift, dan objective C.

<!-- <h2 class="has-text-centered">Artikel</h2>  -->
