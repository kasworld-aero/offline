---
title: Dart
url: /dart/
noTimeEstimate: true
page: true
---

Dart merupakan bahasa pemrograman general-pupose yang dirancang oleh [Lars Bak](https://en.wikipedia.org/wiki/Lars_Bak_(computer_programmer)) dan [Kasper Lund](http://verdich.dk/kasper/) dan dikembangkan oleh [Google](https://google.com). Bahasa ini dirancang untuk mempermudahkan developer untuk mengembangkan app nya untuk disegala platform / multiplatform. 

Dart salah satu bahasa pemrograman yang ada yang menggunkan gaya pemrograman bersifat object oriented atau OOP. Dart senderi menggunakan gaya sintaks bahasa C yang yang dikompile ke dalam bahasa javascript. 

Dart diresmikan pada konverensi GOTO, Denmark 10-12 Oktober 2011. Dart pertama kali rilis Dart 1.0 pada tahun 14 November 2013. 

<h2 class="center t-s p-1">Artikel</h2> 
