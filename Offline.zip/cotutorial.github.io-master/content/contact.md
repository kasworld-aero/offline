---
title: Contact 📨️
noTimeEstimate: true
url: /contact/
page: true
form: true
---

Kami akan sangat senang mendengar masukan dan saran dari Anda, karena masukan Anda sangat berarti bagi Kami. Silahkan hubungi kami melalui kontak form berikut.
  <div>
		<form method="post" id="contact-form" action="https://formspree.io/wisnukey1@gmail.com" target="_top" >
			<label for="name">Name</label>
			<input type="text" name="name" id="name" placeholder="Your Name" required />
			<label for="email">Email</label>
			<input type="email" name="email" id="email" placeholder="mail@example.com" required />
			<label for="message">Message</label>
			<textarea name="message" id="message" placeholder="Message"></textarea> 
			<input type="submit" value="Send" class="button primary"/>
		</form>
	</div>
