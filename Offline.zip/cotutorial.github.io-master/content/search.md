---
title: Search 🔍️
noTimeEstimate: true
url: /search/
noTimeEstimate: true
aliases:
  - /cari/
page: true
---
<div>
    <form method="GET" class="p2" action="https://www.google.com/cse" target="_top" id="contact-form">
      <div class="search">
        <input name="cx" type="hidden" value="001590533446650232000:eeccp1szhaf"/>
        <input name="ie" type="hidden" value="UTF-8" />
        <input type="search" placeholder="Search..." name="q" required>
        <input type="submit" value="Go" class="button primary">
      </div>
    </form>
</div>
Cari sesuatu pada CoTutorial dengan ketikkan keyword di form search.